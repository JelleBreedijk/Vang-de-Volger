﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Drawing;

namespace Vang_de_Volger_Project
{
    class GameObject
    {
        private string _directory;
        private Random _rnd;
        private int _percentage;
        private GameObject _tempObject;
        private Image _tempImage;

        public GameObject(string directoryParameter, Image tempImageParameter)
        {
            _directory = directoryParameter = Directory.GetCurrentDirectory();
            _tempImage = tempImageParameter;
        }

        public GameObject createGameObject()
        {
            _percentage = _rnd.Next(1, 101);
            if (_percentage >= 1 && _percentage <= 5)
            {
                _percentage = 5;
            }
            else if (_percentage >= 6 && _percentage <= 20)
            {
                _percentage = 20;
            }

            switch (_percentage)
            {
                case 5:
                    Wall wallObject = new Wall(_directory, _tempImage);
                    _tempObject = wallObject;
                    break;
                case 20:
                    Box boxObject = new Box(_directory, _tempImage);
                    _tempObject = boxObject;
                    break;
            }
            return _tempObject;
        }

        public Image getImage()
        {
            return _tempImage;
        }
    }
}
