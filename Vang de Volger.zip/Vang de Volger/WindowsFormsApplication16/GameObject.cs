﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Drawing;
using System.Resources;
using System.Reflection;
using Vang_de_Volger_Project.Properties;

namespace Vang_de_Volger_Project
{
    class GameObject
    {
        protected Image _tempImage;
        public GameObject(string _image)
        {
            ResourceManager rm = Resources.ResourceManager;
            _tempImage = (Image)rm.GetObject(_image);
        }

        public Image getImage()
        {
            return _tempImage;
        }
    }
}