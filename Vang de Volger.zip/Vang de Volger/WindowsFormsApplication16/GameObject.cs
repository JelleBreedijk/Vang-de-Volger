﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Drawing;

namespace Vang_de_Volger_Project
{
    class GameObject
    {
        protected Image _tempImage;

        public GameObject(string _image)
        {
            _tempImage = Image.FromFile(Directory.GetCurrentDirectory() + _image);
        }

        public Image getImage()
        {
            return _tempImage;
        }
    }
}
