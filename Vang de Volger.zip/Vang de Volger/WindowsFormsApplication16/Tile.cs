﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vang_de_Volger_Project
{
    class Tile
    {
        private Size _imageSize;
        private Bitmap _bitmap;
        private GameObject class_GameObject;
        private LevelSetting class_LevelSetting;
        private GameObject _tileObject;
        private Tile[,] _tileMap;
         
        public Tile()
        {

            _imageSize = new Size(50,50);
            _tileObject = class_GameObject.createGameObject();
        }

        public Bitmap generateTileGrid()
        {
            _tileMap = class_LevelSetting.getDifficulty();

            for (int height = 0; height < _tileMap.GetLength(1); height++)
            {
                for (int width = 0; width < _tileMap.GetLength(0); width++)
                {
                    _tileMap[width, height] = new Tile();

                    using (Graphics g = Graphics.FromImage(_bitmap))
                    {
                        g.DrawImage(class_GameObject.getImage(), width * _imageSize.Width, height * _imageSize.Height, width, height);
                    }
                }
            }
            return _bitmap;
            
        }
    }
}


			
		