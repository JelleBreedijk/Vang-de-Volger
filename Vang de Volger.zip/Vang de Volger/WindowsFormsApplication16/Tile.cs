﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vang_de_Volger_Project
{
    class Tile
    {

        private static Random _random = new Random();
        private GameObject _gameObject;
        private Dictionary<Tile, EDirection.Direction> dictionary;


        public Tile()
        {
            dictionary = new Dictionary<Tile, EDirection.Direction>();

        }

        public void createGameObject()
        {
            int percentage = _random.Next(1, 101);

            if (percentage >= 1 && percentage <= 5)
            {
                _gameObject = new Wall();
            }
            else if (percentage >= 6 && percentage <= 20)
            {
                _gameObject = new Box();
            }
            else
            {
                _gameObject = null;
            }
        }
        public void setPlayer()
        {
            _gameObject = new Player();
        }

        public void setEnemy()
        {
            _gameObject = new Enemy();
        }

        public Tile getPlayerTile()
        {

            return 
        }

        public Image getImage()
        {
            if (_gameObject != null)
            {
                return _gameObject.getImage();
            }
            else
            {
                return null;
            }
        }


        public void setDictionary(Tile right, Tile down, Tile thisTile)
        {
            if (right != null)
            {
                dictionary.Add(right, EDirection.Direction.RIGHT);

                if (right.dictionary == null)
                {
                    right.dictionary.Add(thisTile, EDirection.Direction.LEFT);
                }
            }

            else if (down != null)
            {
                dictionary.Add(down, EDirection.Direction.DOWN);

                if (down.dictionary == null)
                {
                    down.dictionary.Add(thisTile, EDirection.Direction.UP);
                }
            }
        }

    }
}