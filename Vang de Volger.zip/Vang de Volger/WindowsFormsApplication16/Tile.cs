﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vang_de_Volger_Project
{
    class Tile
    {

        private static readonly Random _random = new Random();
        private GameObject _gameObject;

        private Dictionary<Tile, Direction> dictionary;


        public Tile()
        {
            dictionary = new Dictionary<Tile, Direction>();
            createGameObject();
        }

        private void createGameObject()
        {
            int _percentage = _random.Next(1, 101);
            //if (width == 0 && height == 0)
            //{
            //    _gameObject = new Player();
            //}
            //else if (width == tileMap.GetLength(0) - 1 && height == tileMap.GetLength(1) - 1)
            //{
            //    _gameObject = new Enemy();
            //}
        
            if (_percentage >= 1 && _percentage <= 5)
            {
                _gameObject = new Wall();
            }
            else if (_percentage >= 6 && _percentage <= 20)
            {
                _gameObject = new Box();
            }
            else
            {
                _gameObject = new Path();
            }
        }

                public Image getImage()
        {
            return _gameObject.getImage();
        }

        public void setDictionary(Tile left, Tile up, Tile thisTile)
        {           
            if (left != null)
            {
                dictionary.Add(left, Direction.LEFT);
            }

            else if (up != null)
            {
                dictionary.Add(up, Direction.UP);
            }

            else if (left == null && up == null)
            {
                _gameObject = new Player();
            }

            else if (up.dictionary == null)
            {
                up.dictionary.Add(thisTile, Direction.DOWN);
            }

            else if (left.dictionary == null)
            {
                left.dictionary.Add(thisTile, Direction.RIGHT);
            }

        }

    }
}		