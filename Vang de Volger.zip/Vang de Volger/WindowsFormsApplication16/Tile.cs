﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vang_de_Volger_Project
{
    class Tile
    {
        private static readonly Random _random = new Random();
        private GameObject _gameObject;

        public Tile()
        {
            createGameObject();
        }

        private void createGameObject()
        {
            int _percentage = _random.Next(1, 101);
            if (_percentage >= 1 && _percentage <= 5)
            {
                _gameObject = new Wall();
            }
            else if (_percentage >= 6 && _percentage <= 20)
            {
                _gameObject = new Box();
            } else
            {
                _gameObject = new Path();
            }
        }

        public Image getImage()
        {
            return _gameObject.getImage();
        }


    }
}


			
		