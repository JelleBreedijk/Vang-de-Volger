﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Vang_de_Volger_Project;
using System.Timers;

namespace Vang_de_Volger_Project
{
    public partial class Game : Form, IView
    {
        private int min, sec, ms = 0;
        private GameEngine class_GameEngine;

        public Game()
        {
            //Contructor 
            InitializeComponent();
            System.Timers.Timer _timer = new System.Timers.Timer();
            class_GameEngine = new GameEngine(this);
        }

        private void resetTimer()
        {
            Timer1.Stop();
            min = 0;
            sec = 0;
            ms = 0;

        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            Timer1.Start();
            btnStart.Text = "Start";
        }

        private void btnPause_Click(object sender, EventArgs e)
        {
            Timer1.Stop();
            btnStart.Text = "Resume";
        }

        //set difficulty
        private void easyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            resetTimer();
            class_GameEngine.setDifficulty(EDifficulty.Difficulty.EASY);

        }

        private void medium_DifficultyMenuItem_Click(object sender, EventArgs e)
        {
            resetTimer();
            class_GameEngine.setDifficulty(EDifficulty.Difficulty.MEDIUM);
        }

        private void hard_DifficultyMenuItem_Click(object sender, EventArgs e)
        {
            resetTimer();
            class_GameEngine.setDifficulty(EDifficulty.Difficulty.HARD);
        }

        private void btnRetry_Click(object sender, EventArgs e)
        {
            class_GameEngine.reset();
            resetTimer();
            Timer1.Start();
        }

        private void control_KeyDown(object sender, KeyEventArgs e)
            {
            char keyChar;
            switch (e.KeyData)
            {
                case Keys.W:
                    {
                        keyChar = 'w';
                        break;
                    }
                case Keys.A:
                    {
                        keyChar = 'a';
                        
                        break;
                    }
                case Keys.S:
                    {
                        keyChar = 's';
                        break;
                    }
                case Keys.D:
                    {
                        keyChar = 'd';
                        break;
                    }
            }
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            lblTimer.Text = ("Tijd: " + min + ": " + sec + " " + ": " + ms.ToString());
            ms++;
            if (ms >= 10)
            {
                ms = 0;
                sec++;
            }
            if (sec >= 60)
            {
                sec = 0;
                min++;
            }
        }

        public void setPlayingField(Bitmap bitmap)
        {
            this.playing_Field.Image = bitmap;
        }
    }
}
