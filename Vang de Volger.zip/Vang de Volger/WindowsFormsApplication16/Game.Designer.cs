﻿namespace Vang_de_Volger_Project
{
    partial class Game
    {
                /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Game));
            this.btnStart = new System.Windows.Forms.Button();
            this.btnPause = new System.Windows.Forms.Button();
            this.btnRetry = new System.Windows.Forms.Button();
            this.lblMessenger = new System.Windows.Forms.Label();
            this.lblLevel_Name = new System.Windows.Forms.Label();
            this.lblTimer = new System.Windows.Forms.Label();
            this.Timer1 = new System.Windows.Forms.Timer(this.components);
            this.playing_Field = new System.Windows.Forms.PictureBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.menuSettings = new System.Windows.Forms.ToolStripMenuItem();
            this.difficulty_MenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.easyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.medium_DifficultyMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hard_DifficultyMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.playing_Field)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnStart
            // 
            this.btnStart.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStart.Location = new System.Drawing.Point(9, 526);
            this.btnStart.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(116, 41);
            this.btnStart.TabIndex = 1;
            this.btnStart.Text = "Start";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // btnPause
            // 
            this.btnPause.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPause.Location = new System.Drawing.Point(137, 526);
            this.btnPause.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnPause.Name = "btnPause";
            this.btnPause.Size = new System.Drawing.Size(118, 41);
            this.btnPause.TabIndex = 2;
            this.btnPause.Text = "Pause";
            this.btnPause.UseVisualStyleBackColor = true;
            this.btnPause.Click += new System.EventHandler(this.btnPause_Click);
            // 
            // btnRetry
            // 
            this.btnRetry.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRetry.Location = new System.Drawing.Point(427, 527);
            this.btnRetry.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnRetry.Name = "btnRetry";
            this.btnRetry.Size = new System.Drawing.Size(77, 41);
            this.btnRetry.TabIndex = 3;
            this.btnRetry.Text = "Retry";
            this.btnRetry.UseVisualStyleBackColor = true;
            this.btnRetry.Click += new System.EventHandler(this.btnRetry_Click);
            // 
            // lblMessenger
            // 
            this.lblMessenger.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMessenger.Location = new System.Drawing.Point(260, 534);
            this.lblMessenger.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblMessenger.Name = "lblMessenger";
            this.lblMessenger.Size = new System.Drawing.Size(163, 32);
            this.lblMessenger.TabIndex = 4;
            this.lblMessenger.Text = "Message";
            // 
            // lblLevel_Name
            // 
            this.lblLevel_Name.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLevel_Name.Location = new System.Drawing.Point(214, -2);
            this.lblLevel_Name.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblLevel_Name.Name = "lblLevel_Name";
            this.lblLevel_Name.Size = new System.Drawing.Size(139, 25);
            this.lblLevel_Name.TabIndex = 6;
            this.lblLevel_Name.Text = "LEVEL";
            // 
            // lblTimer
            // 
            this.lblTimer.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTimer.Location = new System.Drawing.Point(346, 0);
            this.lblTimer.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTimer.Name = "lblTimer";
            this.lblTimer.Size = new System.Drawing.Size(169, 23);
            this.lblTimer.TabIndex = 8;
            this.lblTimer.Text = "Tijd:";
            // 
            // Timer1
            // 
            this.Timer1.Tick += new System.EventHandler(this.Timer_Tick);
            // 
            // playing_Field
            // 
            this.playing_Field.BackColor = System.Drawing.Color.Transparent;
            this.playing_Field.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.playing_Field.Location = new System.Drawing.Point(0, 23);
            this.playing_Field.Margin = new System.Windows.Forms.Padding(0);
            this.playing_Field.Name = "playing_Field";
            this.playing_Field.Size = new System.Drawing.Size(515, 501);
            this.playing_Field.TabIndex = 9;
            this.playing_Field.TabStop = false;
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuSettings});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(515, 24);
            this.menuStrip1.TabIndex = 10;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // menuSettings
            // 
            this.menuSettings.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.difficulty_MenuItem});
            this.menuSettings.Name = "menuSettings";
            this.menuSettings.Size = new System.Drawing.Size(61, 20);
            this.menuSettings.Text = "Settings";
            // 
            // difficulty_MenuItem
            // 
            this.difficulty_MenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.easyToolStripMenuItem,
            this.medium_DifficultyMenuItem,
            this.hard_DifficultyMenuItem});
            this.difficulty_MenuItem.Name = "difficulty_MenuItem";
            this.difficulty_MenuItem.Size = new System.Drawing.Size(122, 22);
            this.difficulty_MenuItem.Text = "Difficulty";
            // 
            // easyToolStripMenuItem
            // 
            this.easyToolStripMenuItem.Name = "easyToolStripMenuItem";
            this.easyToolStripMenuItem.Size = new System.Drawing.Size(119, 22);
            this.easyToolStripMenuItem.Text = "Easy";
            this.easyToolStripMenuItem.Click += new System.EventHandler(this.easyToolStripMenuItem_Click);
            // 
            // medium_DifficultyMenuItem
            // 
            this.medium_DifficultyMenuItem.Name = "medium_DifficultyMenuItem";
            this.medium_DifficultyMenuItem.Size = new System.Drawing.Size(119, 22);
            this.medium_DifficultyMenuItem.Text = "Medium";
            this.medium_DifficultyMenuItem.Click += new System.EventHandler(this.medium_DifficultyMenuItem_Click);
            // 
            // hard_DifficultyMenuItem
            // 
            this.hard_DifficultyMenuItem.Name = "hard_DifficultyMenuItem";
            this.hard_DifficultyMenuItem.Size = new System.Drawing.Size(119, 22);
            this.hard_DifficultyMenuItem.Text = "Hard";
            this.hard_DifficultyMenuItem.Click += new System.EventHandler(this.hard_DifficultyMenuItem_Click);
            // 
            // Vang_de_Volger
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(515, 574);
            this.Controls.Add(this.playing_Field);
            this.Controls.Add(this.lblTimer);
            this.Controls.Add(this.lblLevel_Name);
            this.Controls.Add(this.lblMessenger);
            this.Controls.Add(this.btnRetry);
            this.Controls.Add(this.btnPause);
            this.Controls.Add(this.btnStart);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.MinimumSize = new System.Drawing.Size(78, 88);
            this.Name = "Vang_de_Volger";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "Vang de Volger";
            ((System.ComponentModel.ISupportInitialize)(this.playing_Field)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.Button btnPause;
        private System.Windows.Forms.Button btnRetry;
        private System.Windows.Forms.Label lblMessenger;
        private System.Windows.Forms.Label lblLevel_Name;
        private System.Windows.Forms.Label lblTimer;
        private System.Windows.Forms.Timer Timer1;
        private System.Windows.Forms.PictureBox playing_Field;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem menuSettings;
        private System.Windows.Forms.ToolStripMenuItem difficulty_MenuItem;
        private System.Windows.Forms.ToolStripMenuItem medium_DifficultyMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hard_DifficultyMenuItem;
        private System.Windows.Forms.ToolStripMenuItem easyToolStripMenuItem;
    }
}

