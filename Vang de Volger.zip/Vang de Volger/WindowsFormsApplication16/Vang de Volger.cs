﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Vang_de_Volger_Project;
using System.Timers;

namespace Vang_de_Volger_Project
{
    public partial class Vang_de_Volger : Form
    {
        private int min, sec, ms = 0;
        private LevelSetting class_LevelSetting;
        private int tempDifficulty;

        public Vang_de_Volger()
        {
            class_LevelSetting = new LevelSetting();
            Lvl_Draw class_Draw = new Lvl_Draw();
            //Contructor 
            InitializeComponent();
            System.Timers.Timer _timer = new System.Timers.Timer();


            
            playing_Field.Image = class_Draw.generateForm(class_LevelSetting.getDifficulty());

        }

        private void resetTimer()
        {
            Timer1.Stop();
            min = 0;
            sec = 0;
            ms = 0;
            
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            Timer1.Start();
            btnStart.Text = "Start";
            
            if ((min == 0 )&& (sec == 0) && (ms == 0))
            {
                lblMessenger.Text = "Good luck!";
            }
            else
            {
                lblMessenger.Text = "Resumed";
            }
        }

        private void btnPause_Click(object sender, EventArgs e)
        {
            Timer1.Stop();
            lblMessenger.Text = "Paused";
            btnStart.Text = "Resume";
        }
        
        //set difficulty
        private void easyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            resetTimer();
            tempDifficulty = 0;
            class_LevelSetting.setDifficulty(tempDifficulty);
            Lvl_Draw class_Draw = new Lvl_Draw();
            playing_Field.Image = class_Draw.generateForm(class_LevelSetting.getDifficulty());

        }

        private void medium_DifficultyMenuItem_Click(object sender, EventArgs e)
        {
            resetTimer();
            tempDifficulty = 1;
            class_LevelSetting.setDifficulty(tempDifficulty);
            Lvl_Draw class_Draw = new Lvl_Draw();
            playing_Field.Image = class_Draw.generateForm(class_LevelSetting.getDifficulty());
        }

        private void hard_DifficultyMenuItem_Click(object sender, EventArgs e)
        {
            resetTimer();
            tempDifficulty = 2;
            class_LevelSetting.setDifficulty(tempDifficulty);
            Lvl_Draw class_Draw = new Lvl_Draw();
            playing_Field.Image = class_Draw.generateForm(class_LevelSetting.getDifficulty());
        }

        private void btnRetry_Click(object sender, EventArgs e)
        {

            Lvl_Draw class_Draw = new Lvl_Draw();
            playing_Field.Image = class_Draw.generateForm(class_LevelSetting.getDifficulty());
            resetTimer();
            Timer1.Start();
            lblMessenger.Text = "Good Luck!";
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            lblTimer.Text = ("Tijd: " + min + ": " + sec + " " + ": " + ms.ToString());
            ms++;
            if (ms >= 10)
            {
                ms = 0;
                sec++;
            }
            if (sec >= 60)
            {
                sec = 0;
                min++;
            }
        }
    }
}
