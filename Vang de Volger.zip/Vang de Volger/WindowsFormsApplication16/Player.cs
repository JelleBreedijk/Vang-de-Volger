﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vang_de_Volger_Project
{
    class Player
    {
        /* private bool die()
         {
             bool status;
             //nog in te vullen if
             //als player geraakt of klem status = true
             if (true)
             {
                 status = true;
             }
             else
             {
                 status = false;
             }
             return status;

         }*/

        private void push_Box()
        {

        }

    }
}
