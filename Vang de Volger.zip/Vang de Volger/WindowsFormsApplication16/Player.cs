﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vang_de_Volger_Project
{
    class Player : GameObject
    {
        public Player() : base(@"hulk")
        {
            
        }

        public void move(char key)
        {
            switch (key)
            {
                case 's':
                    tile.getPlayerTile();
                    break;

                default:
                    break;
            }
        }


    }
}
