﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Vang_de_Volger_Project
{
    public enum Difficulty
    {
        EASY = 10,
        MEDIUM = 15,
        HARD = 18
    };

    public enum Direction
    {
        UP,
        DOWN,
        LEFT,
        RIGHT
    };

    class GameEngine
    {

        private Size _imageSize = new Size(50, 50);
        private Tile[,] _tileMap;
        private Difficulty _difficulty;
        private IView _view;
        private Bitmap _bitmap;


        public GameEngine(IView view)
        {
            _view = view;
            setDifficulty(Difficulty.EASY);
        }

        public void setDifficulty(Difficulty difficulty)
        {
            _difficulty = difficulty;
            generateTileGrid();
        }

        public void reset()
        {
            generateTileGrid();
        }

        public void generateTileGrid()
        {
            GC.Collect();
            _tileMap = new Tile[(int)_difficulty, (int)_difficulty];
            _bitmap = new Bitmap((int)_difficulty * _imageSize.Width, (int)_difficulty * _imageSize.Height);


            Graphics g = Graphics.FromImage(_bitmap);
            for (int height = 0; height < _tileMap.GetLength(1); height++)
            {
                for (int width = 0; width < _tileMap.GetLength(0); width++)
                {
                    Tile tile = new Tile();
                    _tileMap[width, height] = tile;
                    g.DrawImage(tile.getImage(), width * _imageSize.Width, height * _imageSize.Height, _imageSize.Width, _imageSize.Height);
                }
            }
            for (int height = _tileMap.GetLength(1); height >= 0; height--)
            {
                for (int width = _tileMap.GetLength(0); width >= 0; width--)
                {
                    if (width == 0 && height != 0)
                    {
                        _tileMap[width, height].setDictionary(null, _tileMap[width, height - 1], _tileMap[width, height]);
                    }
                    else if (width != 0 && height == 0)
                    {
                        _tileMap[width, height].setDictionary(_tileMap[width - 1, height], null, _tileMap[width, height]);
                    }
                    else if (width == 0 && height == 0)
                    {
                        _tileMap[width, height].setDictionary(null, null, _tileMap[width, height]);
                    }
                    else
                    {
                        _tileMap[width, height].setDictionary(_tileMap[width - 1, height], _tileMap[width, height - 1], _tileMap[width, height]);
                    }
                }
            }

            _view.setPlayingField(_bitmap);
        }
    }
}