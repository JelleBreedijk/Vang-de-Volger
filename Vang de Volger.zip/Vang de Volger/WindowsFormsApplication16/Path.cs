﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vang_de_Volger_Project
{
    class Path : GameObject
    {
        public Path(string directory, Image pathImage) : base(directory, pathImage)
        {
            pathImage = Image.FromFile(directory + @"\resources\path.jpg");
        }
    }
}
