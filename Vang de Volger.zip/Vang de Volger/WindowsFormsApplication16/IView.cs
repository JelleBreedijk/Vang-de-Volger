﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace Vang_de_Volger_Project
{
    interface IView
    {
        void setPlayingField(Bitmap bitmap);
    }
}
