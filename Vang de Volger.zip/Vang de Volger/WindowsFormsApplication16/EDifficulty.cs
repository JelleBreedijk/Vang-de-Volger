﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vang_de_Volger_Project
{
    class EDifficulty
    {
        public enum Difficulty
        {
            EASY = 10,
            MEDIUM = 15,
            HARD = 18
        };
    }
}
