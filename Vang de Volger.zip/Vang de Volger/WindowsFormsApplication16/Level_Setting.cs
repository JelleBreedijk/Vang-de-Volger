﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vang_de_Volger_Project
{
    class Level_Setting
    {
        private Tile[,] difficulty;

        public void setDifficulty(int difficultySetting)
        {
            switch (difficultySetting)
            {
                case 1:
                    difficulty = new Tile[20, 20];
                    break;

                case 2:
                    difficulty = new Tile[40, 40];
                    break;

                default:
                    difficulty = new Tile[10, 10];
                    break;
            }
        }

        public Tile[,] getDifficulty()
        {
            return difficulty;
        }
    }
}