﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Vang_de_Volger_Project
{
    class Lvl_Draw
    {
        private string directory;
        private int x;
        private int y;
        private int xBitmap;
        private int yBitmap;

        public Lvl_Draw()
        {
            x = 50;
            y = 50;
            xBitmap = 550;
            yBitmap = 550;
            directory = Directory.GetCurrentDirectory();
        }

        public Bitmap generateForm()
        {

            Image wall = Image.FromFile(directory + @"\resources\wall.jpg");
            Image Path = Image.FromFile(directory + @"\resources\path.jpg");
            Image Box = Image.FromFile(directory + @"\resources\box.jpg");
            Bitmap b = new Bitmap(xBitmap, yBitmap);
            

            Random rnd = new Random();
            int[,] level = new int[11, 11];

            
            for (int i = 0; i < level.GetLength(0); i++)
            {
                for (int j = 0; j < level.GetLength(0); j++)
                {
                    level[i, j] = rnd.Next(0, 6);
                    if (i == 0 || i == 10)
                    {
                        using (Graphics g = Graphics.FromImage(b))
                        {
                            g.DrawImage(wall, j * x, i * y, x, y);
                        }
                    }
                    else if (j == 0 || j == 10)
                    {
                        using (Graphics g = Graphics.FromImage(b))
                        {
                            g.DrawImage(wall, j * x, i * y, x, y);
                        }
                    }
                    else if (level[i, j] == 0 || level[i, j] == 1 || level[i, j] == 2 || level[i, j] == 3 || level[i, j] == 4)
                    {
                        using (Graphics g = Graphics.FromImage(b))
                        {
                            g.DrawImage(Path, i * x, j * y, x, y);
                        }
                    }
                    else if (level[i, j] == 5)
                    {
                        using (Graphics g = Graphics.FromImage(b))
                        {
                            g.DrawImage(Box, i * x, j * y, x, y);
                        }
                    }
                }
            }
            return b;
        }

    }
}

