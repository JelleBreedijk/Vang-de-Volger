﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Vang_de_Volger_Project
{
    class Lvl_Draw
    {
        private int x;
        private int y;
        private int xBitmap;
        private int yBitmap;
        private string directory;
        private int percentage;


        public Lvl_Draw()
        {
            y = 50;
            x = 50;
            xBitmap = 668;
            yBitmap = 617;
            directory = Directory.GetCurrentDirectory();
        }

        public Bitmap generateForm(Tile[,] difficulty)
        {
            Image wall = Image.FromFile(directory + @"\resources\wall.jpg");
            Image path = Image.FromFile(directory + @"\resources\path.jpg");
            Image box = Image.FromFile(directory + @"\resources\box.jpg");
            Image playerTile = Image.FromFile(directory + @"\resources\start.jpg");
            Image enemyTile = Image.FromFile(directory + @"\resources\lava.jpg");

            Bitmap b = new Bitmap(xBitmap, yBitmap);

            
            Random rnd = new Random();
            //Als er geen difficulty gegeven is, start met deze standaard:
            if (difficulty == null)
            {
                difficulty = new Tile[10, 10];
            }
            //scale de grootte van de tegels
            if (difficulty.GetLength(0) == 20)
            {
                x = x / 2;
                y = y / 2;
            }
            else if (difficulty.GetLength(0) == 40)
            {
                x = x / 4;
                y = y / 4;
            }
            //start loop door Tile[,]
            for (int i = 0; i < difficulty.GetLength(0); i++)
            {
                for (int j = 0; j < difficulty.GetLength(1); j++)
                {


                    
                    //vult percentage met een random getal tussen de 1 en 100
                    percentage = rnd.Next(1, 101);
                    //5% wall
                    if (percentage >= 1 && percentage <= 5)
                    {
                        using (Graphics g = Graphics.FromImage(b))
                        {
                            g.DrawImage(wall, j * x, i * y, x, y);
                        }
                    }
                    //20% box
                    else if (percentage >= 6 && percentage <= 25)
                    {
                        using (Graphics g = Graphics.FromImage(b))
                        {
                            g.DrawImage(box, j * x, i * y, x, y);
                        }
                    }
                    //rest is path
                    else
                    {
                        using (Graphics g = Graphics.FromImage(b))
                        {
                            g.DrawImage(path, j * x, i * y, x, y);
                        }
                    }
                    

                    //als i gelijk is aan 0 of i is gelijk aan de laatste uit de reeks min 1, dus de een na laatste, teken een muur
                    if ((i == 0) || (i == difficulty.GetLength(0) - 1) || (j == 0) || (j == difficulty.GetLength(1) - 1))
                    {
                        using (Graphics g = Graphics.FromImage(b))
                        {
                            g.DrawImage(wall, j * x, i * y, x, y);
                        }
                    }
                    //als i gelijk is aan 2 en j gelijk is aan 2, teken een speler tegel
                    else if (i == 1 && j == 1)
                    {
                        using (Graphics g = Graphics.FromImage(b))
                        {
                            g.DrawImage(playerTile, j * x, i * y, x, y);
                        }
                    }
                    //als i gelijk is aan de een na laatste horizontaal en j gelijk is aan de een na laatste van verticaal, teken een enemy tegel
                    else if (i == difficulty.GetLength(0) - 2 && j == difficulty.GetLength(0) - 2)
                    {
                        using (Graphics g = Graphics.FromImage(b))
                        {
                            g.DrawImage(enemyTile, j * x, i * y, x, y);
                        }
                    }
                }
            }
            return b;
        }

    }
}

