﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Vang_de_Volger_Project
{
    class Lvl_Draw
    {
        private int x;
        private int y;
        private int xBitmap;
        private int yBitmap;
        

        public Lvl_Draw()
        {
            x = 50;
            y = 50;
            xBitmap = 550;
            yBitmap = 550;
        }

        public Bitmap generateForm(int[,] Difficulty)
        {
            Image wall = Image.FromFile(@"C: \Users\jorre\Documents\Haagse hogeschool HBO ICT\0Software Engineering\Periode 3 C#\Afbeeldingen\wall.jpg");
            Image Path = Image.FromFile(@"C: \Users\jorre\Documents\Haagse hogeschool HBO ICT\0Software Engineering\Periode 3 C#\Afbeeldingen\path.png");
            Image Box = Image.FromFile(@"C:\Users\jorre\Documents\Haagse hogeschool HBO ICT\0Software Engineering\Periode 3 C#\Afbeeldingen\Box.jpg");
            Bitmap b = new Bitmap(xBitmap, yBitmap);
            

            Random rnd = new Random();
            //int[,] level = new int[11, 11];
            if (Difficulty == null)
            {
                Difficulty = new int[11, 11];
            }

            
            for (int i = 0; i < Difficulty.GetLength(0); i++)
            {
                for (int j = 0; j < Difficulty.GetLength(0); j++)
                {
                    Difficulty[i, j] = rnd.Next(0, 6);
                    if (i == 0 || i == 10)
                    {
                        using (Graphics g = Graphics.FromImage(b))
                        {
                            g.DrawImage(wall, j * x, i * y, x, y);
                        }
                    }
                    else if (j == 0 || j == 10)
                    {
                        using (Graphics g = Graphics.FromImage(b))
                        {
                            g.DrawImage(wall, j * x, i * y, x, y);
                        }
                    }
                    else if (Difficulty[i, j] == 0 || Difficulty[i, j] == 1 || Difficulty[i, j] == 2 || Difficulty[i, j] == 3 || Difficulty[i, j] == 4)
                    {
                        using (Graphics g = Graphics.FromImage(b))
                        {
                            g.DrawImage(Path, i * x, j * y, x, y);
                        }
                    }
                    else if (Difficulty[i, j] == 5)
                    {
                        using (Graphics g = Graphics.FromImage(b))
                        {
                            g.DrawImage(Box, i * x, j * y, x, y);
                        }
                    }
                }
            }
            return b;
        }

    }
}

