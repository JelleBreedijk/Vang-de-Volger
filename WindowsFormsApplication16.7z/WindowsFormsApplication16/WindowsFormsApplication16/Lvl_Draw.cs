﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Vang_de_Volger_Project
{
    class Lvl_Draw 
    {
        private int x = 100;
        private int y;
        private int pbWidth = 757;
        private int pbHeight = 653;

        public Lvl_Draw()
        {
            x = 100;
            y = 100;
            pbHeight = 757;
            pbWidth = 635;
        }


        //public void Draw(PictureBox PF)
        //{

        //    //PictureBox playing_Field;
        //    //playing_Field.Location = new Point();
        //    //playing_Field.Width = pbWidth;
        //    //playing_Field.Height = pbHeight;
        //    //Controls.Add(playing_Field);



        //    Image wall = Image.FromFile(@"C: \Users\jorre\Documents\Haagse hogeschool HBO ICT\0Software Engineering\Periode 3 C#\Afbeeldingen\wall.jpg");

        //    Bitmap b = new Bitmap(500, 500);


        //    using (Graphics g = Graphics.FromImage(b))
        //    {
        //        g.DrawImage(wall, 0, 0, x, y);
        //    }
        //    PF.Image = b;
        //}


        public Bitmap generateForm()
        {

            //PictureBox playing_Field;
            //playing_Field.Location = new Point();
            //playing_Field.Width = pbWidth;
            //playing_Field.Height = pbHeight;
            //Controls.Add(playing_Field);



            Image wall = Image.FromFile(@"C: \Users\jorre\Documents\Haagse hogeschool HBO ICT\0Software Engineering\Periode 3 C#\Afbeeldingen\wall.jpg");

            Bitmap b = new Bitmap(500, 500);


            using (Graphics g = Graphics.FromImage(b))
            {
                g.DrawImage(wall, 0, 0, x, y);
            }
            return b;
        }



    }
}




