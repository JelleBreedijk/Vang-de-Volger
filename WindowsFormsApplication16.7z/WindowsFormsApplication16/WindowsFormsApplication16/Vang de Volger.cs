﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Vang_de_Volger_Project;
using System.Timers;

namespace Vang_de_Volger_Project
{
    public partial class Vang_de_Volger : Form
    {
        int Min, Sec, Ms = 0;



        public Vang_de_Volger()
        {
            //Contructor 
            InitializeComponent();
            System.Timers.Timer _timer = new System.Timers.Timer();

            Lvl_Draw class_Draw = new Lvl_Draw();
            playing_Field.Image = class_Draw.generateForm();

        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            Timer1.Start();
            btnStart.Text = "Start";
            lblMessenger.Text = "Resumed";
        }

        private void btnPause_Click(object sender, EventArgs e)
        {
            Timer1.Stop();
            lblMessenger.Text = "Paused";
            btnStart.Text = "Resume";
        }

        private void btnRetry_Click(object sender, EventArgs e)
        {
            Lvl_Draw class_Draw = new Lvl_Draw();
            playing_Field.Image = class_Draw.generateForm();
            Min = 0;
            Sec = 0;
            Ms = 0;
            Timer1.Start();
            lblMessenger.Text = "Good Luck!";
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            lblTimer.Text = ("Tijd: " + Min + ": " + Sec + " " + ": " + Ms.ToString());
            Ms++;
            if (Ms >= 10)
            {
                Ms = 0;
                Sec++;
            }
            if (Sec >= 60)
            {
                Sec = 0;
                Min++;
            }
        }

    }
}
