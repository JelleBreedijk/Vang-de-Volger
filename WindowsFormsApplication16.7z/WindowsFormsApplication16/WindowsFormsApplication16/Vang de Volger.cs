﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Vang_de_Volger_Project;

namespace Vang_de_Volger_Project
{
    public partial class Vang_de_Volger : Form
    {
        Enemy _enemy;
        Stopwatch _sw = new Stopwatch();

        public Vang_de_Volger()
        {
            //Contructor
            InitializeComponent();

            _enemy = new Enemy();
            _enemy.enemyStuff();
        }

        private void eersteMethode()
        {
            _enemy.enemyStuff();
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            _sw.Start();
            TimeSpan t = TimeSpan.FromMilliseconds(_sw.ElapsedMilliseconds);
            lblTimer.Text = "Tijd: " + (String.Format("{0:D2}:{1:D2}.{2:D3}", t.Minutes, t.Seconds, t.Milliseconds));
            
            lblMessenger.Text = "Good luck!";
        }

        private void btnPause_Click(object sender, EventArgs e)
        {
            _sw.Stop();
            lblMessenger.Text = "Paused";
        }

        private void btnRetry_Click(object sender, EventArgs e)
        {
            _sw.Restart();
        }

    }

}
